package com.company;

import java.util.Scanner;
import java.lang.String;
public class Main {

    public static void main(String[] args) {

    }
}
