package com.company;

import java.util.Calendar;
import java.util.Scanner;
import java.lang.String;

public class stringSplit {
    public static void main(String[] args) {
        String str;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter string that contains no more than 60 English letters, numbers, punctuation marks: ");
        str = scan.nextLine();
        if (str.length() < 61) {
            String[] strArray = str.split(" ");
            for (String part : strArray) {
                System.out.println(part);
            }
        } else {
            System.out.println("The length is more than 60 symbols");
        }
        String author = "YANA YUNCHIK";
        Calendar cal = Calendar.getInstance();
// You cannot use Date class to extract individual Date fields
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH); // 0 to 11
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        int second = cal.get(Calendar.SECOND);
        System.out.println("Author: " + author);
        System.out.printf("Date: %4d-%02d-%02d %02d:%02d:%02d\n",
                year, month + 1, day, hour, minute, second);
    }
}
